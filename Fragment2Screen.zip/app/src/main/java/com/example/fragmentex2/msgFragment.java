package com.example.fragmentex2;


import android.app.Activity;
import android.content.Context;
import android.location.OnNmeaMessageListener;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;


/**
 * A simple {@link Fragment} subclass.
 */
public class msgFragment extends Fragment  {

    onMsgSendListener msgSendListener;
     private EditText editText;
     private Button button;
    public interface onMsgSendListener
    {
        public void onMsgSend(String msg);
    }

    public msgFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment


        View view = inflater.inflate(R.layout.fragment_msg, container, false);
        button = view.findViewById(R.id.button);
        editText = view.findViewById(R.id.msgTxt);
        button.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view)
            {
                String msg = editText.getText().toString();
                msgSendListener.onMsgSend(msg);

            }
        });

        return view;

    }

    public void onAttach(Context context){

        super.onAttach( context);
        Activity activity = (Activity)context;

        msgSendListener= (onMsgSendListener)activity;
        try {
            msgSendListener= (onMsgSendListener) activity;
        }catch (ClassCastException e )
        {
            throw new ClassCastException(activity.toString()+ "must override on message read");

        }
    }

    @Override
    public void onResume() {
        super.onResume();
        editText.setText("");
    }
}



